Replication and Data Files for "Who runs the international system?
Nationality and leadership in the United Nations Secretariat,"
by Paul Novosad and Eric Werker.

Please notify us of any corrections that you find or updates to
the dataset.

-----------------------------------------------------------------------

TO RUN REPLICATION FILES:

1. Edit un_include.do and modify global paths in file header.

2. Run make_un.do

-----------------------------------------------------------------------

DESCRIPTION OF RAW DATA

un_staff.dta/csv
----------------

Data on nationality and importance of key positions in the United
Nations Secretariat and Specalized Agencies (1947-2013). Each
observation is a position-year. Duplicate entries indicate either
multiple positions with the same title (e.g. Scientific Advisory
Committee), or individuals held by more than one person in the same
year. Masterposition is a code used internally by the researchers
only. Details on methodology for assigning countries and on the
coverage of the UN Yearbooks can be found in the above paper.
Importance weights are the mean value from two independent
assessments of position importance by UN experts, where 6 is the
highest and 1 is the lowest.

The expert position importance weights were calculated when data was
only available to 2007, so many of these are missing for 2008-2013.

un_rep_analysis.dta/csv
-----------------------

This file aggregates data from un_staff.dta to one observation per
country-year, which descriptions the share of positions held by each
country in a given year (rep_sec_raw), and the importance-weighted
share of positions (rep_sec_wt).  This file also includes various
external country-year-level variables used in analysis, such as number
of embassies (dipcon), and assessment of dues to the United Nations
(assessment).  THIS FILE ONLY GOES UP TO 2007 SINCE THAT IS WHAT WE
USED IN THE PAPER! If you want the data to 2013, use un_staff.csv.

un_regs.dta
-----------

This file is generate from un_rep_analysis.dta, and contains a few
variable transformations used in regressions, such as variable
normalizations.

